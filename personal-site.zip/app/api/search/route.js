import { NextResponse } from 'next/server'
import { OLLAMA_BASE_URL, EMBEDDING_MODEL } from '@/lib/config'
import axios from 'axios'
import cheerio from 'cheerio'
import { readFileSync, writeFileSync, existsSync } from 'fs'

const DOCS_FILE = process.env.DOCS_FILE || './docs.json'

function loadDocs() {
  if (!existsSync(DOCS_FILE)) return []
  try {
    return JSON.parse(readFileSync(DOCS_FILE, 'utf-8'))
  } catch {
    return []
  }
}

function cosineSimilarity(a, b) {
  let dot = 0, normA = 0, normB = 0
  for (let i = 0; i < a.length; i++) {
    dot += a[i] * b[i]
    normA += a[i] * a[i]
    normB += b[i] * b[i]
  }
  return dot / (Math.sqrt(normA) * Math.sqrt(normB))
}

async function fetchPageContent(url) {
  try {
    const response = await axios.get(url, { 
      timeout: 10000,
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
      }
    })
    const $ = cheerio.load(response.data)
    return $('article, .article-content, main, .content, .markdown-body').text().slice(0, 5000)
  } catch {
    return ''
  }
}

export async function POST(request) {
  try {
    const { query } = await request.json()
    
    // 获取 query 的 embedding
    const embedRes = await fetch(`${OLLAMA_BASE_URL}/api/embeddings`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ model: EMBEDDING_MODEL, prompt: query })
    })
    
    if (!embedRes.ok) {
      throw new Error('Embedding 服务不可用')
    }
    
    const { embedding: queryEmbed } = await embedRes.json()

    // 加载文档并计算相似度
    const docs = loadDocs()
    
    if (docs.length === 0) {
      return NextResponse.json({ 
        results: [], 
        contexts: ['知识库暂无文档，请先在管理页面添加文档。'] 
      })
    }

    let results = []
    for (const doc of docs) {
      if (!doc.embedding) continue
      const sim = cosineSimilarity(queryEmbed, doc.embedding)
      results.push({ ...doc, similarity: sim })
    }

    // 排序并取前3
    results.sort((a, b) => b.similarity - a.similarity)
    results = results.slice(0, 3)

    // 抓取内容
    const contexts = await Promise.all(
      results.map(async r => {
        const content = await fetchPageContent(r.url)
        return `【${r.title}】\n${content || '无法获取内容'}`
      })
    )

    return NextResponse.json({ results, contexts })
  } catch (error) {
    console.error('Search error:', error)
    return NextResponse.json({ error: error.message }, { status: 500 })
  }
}
