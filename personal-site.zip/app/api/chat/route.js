import { NextResponse } from 'next/server'
import { OLLAMA_BASE_URL, LLM_MODEL } from '@/lib/config'

export async function POST(request) {
  try {
    const { question, context } = await request.json()

    const prompt = `基于以下上下文回答问题。如果上下文中没有相关信息，请说明不知道。

上下文：
${context}

问题：${question}

回答：`

    const response = await fetch(`${OLLAMA_BASE_URL}/api/generate`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        model: LLM_MODEL,
        prompt,
        stream: false
      })
    })

    if (!response.ok) {
      throw new Error('Ollama 请求失败')
    }

    const data = await response.json()
    return NextResponse.json({ answer: data.response })
  } catch (error) {
    console.error('Chat error:', error)
    return NextResponse.json({ error: '服务暂时不可用，请稍后重试' }, { status: 500 })
  }
}
