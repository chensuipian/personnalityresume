import { NextResponse } from 'next/server'
import { OLLAMA_BASE_URL, EMBEDDING_MODEL } from '@/lib/config'
import { readFileSync, writeFileSync, existsSync } from 'fs'

const DOCS_FILE = process.env.DOCS_FILE || './docs.json'

function loadDocs() {
  if (!existsSync(DOCS_FILE)) return []
  try {
    return JSON.parse(readFileSync(DOCS_FILE, 'utf-8'))
  } catch {
    return []
  }
}

function saveDocs(docs) {
  writeFileSync(DOCS_FILE, JSON.stringify(docs, null, 2))
}

export async function POST(request) {
  try {
    const { url, title } = await request.json()

    if (!url || !title) {
      return NextResponse.json({ success: false, error: '请填写标题和链接' })
    }

    // 检查是否已存在
    const docs = loadDocs()
    if (docs.some(d => d.url === url)) {
      return NextResponse.json({ success: false, error: '文档已存在' })
    }

    // 获取 embedding
    const embedRes = await fetch(`${OLLAMA_BASE_URL}/api/embeddings`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ model: EMBEDDING_MODEL, prompt: title })
    })

    if (!embedRes.ok) {
      return NextResponse.json({ success: false, error: 'Embedding 服务不可用，请确保 Ollama 正在运行' })
    }

    const { embedding } = await embedRes.json()

    // 保存文档
    docs.push({
      id: Date.now().toString(),
      title,
      url,
      embedding,
      createdAt: new Date().toISOString()
    })
    saveDocs(docs)

    return NextResponse.json({ success: true, count: docs.length })
  } catch (error) {
    console.error('Add doc error:', error)
    return NextResponse.json({ success: false, error: error.message })
  }
}

export async function GET() {
  const docs = loadDocs()
  return NextResponse.json({ docs, count: docs.length })
}
