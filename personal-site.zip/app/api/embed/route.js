import { NextResponse } from 'next/server'
import { OLLAMA_BASE_URL, EMBEDDING_MODEL } from '@/lib/config'

export async function POST(request) {
  try {
    const { text } = await request.json()

    const response = await fetch(`${OLLAMA_BASE_URL}/api/embeddings`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        model: EMBEDDING_MODEL,
        prompt: text
      })
    })

    if (!response.ok) {
      throw new Error('Ollama embedding 请求失败')
    }

    const data = await response.json()
    return NextResponse.json({ embedding: data.embedding })
  } catch (error) {
    console.error('Embed error:', error)
    return NextResponse.json({ error: error.message }, { status: 500 })
  }
}
