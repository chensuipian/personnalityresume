'use client'
import { useState, useEffect } from 'react'
import Link from 'next/link'

export default function AdminPage() {
  const [url, setUrl] = useState('')
  const [title, setTitle] = useState('')
  const [message, setMessage] = useState('')
  const [docs, setDocs] = useState([])
  const [loading, setLoading] = useState(false)

  const loadDocs = async () => {
    try {
      const res = await fetch('/api/admin/add')
      const data = await res.json()
      setDocs(data.docs || [])
    } catch {
      console.error('加载文档列表失败')
    }
  }

  useEffect(() => {
    loadDocs()
  }, [])

  const handleSubmit = async (e) => {
    e.preventDefault()
    setLoading(true)
    setMessage('添加中...')

    try {
      const res = await fetch('/api/admin/add', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ url, title })
      })
      const data = await res.json()
      setMessage(data.success ? `✅ 添加成功！当前共 ${data.count} 篇文档` : `❌ ${data.error}`)
      if (data.success) {
        setUrl('')
        setTitle('')
        loadDocs()
      }
    } catch (error) {
      setMessage('❌ 添加失败')
    }

    setLoading(false)
  }

  return (
    <main className="min-h-screen p-8 max-w-4xl mx-auto">
      <header className="flex justify-between items-center mb-8">
        <h1 className="text-2xl font-bold">📚 文档管理</h1>
        <nav className="space-x-6">
          <Link href="/" className="text-blue-600 hover:underline">首页</Link>
          <Link href="/chat" className="text-blue-600 hover:underline">问答</Link>
          <Link href="/admin" className="text-blue-600 hover:underline">管理</Link>
        </nav>
      </header>

      <form onSubmit={handleSubmit} className="bg-white p-6 rounded-lg shadow space-y-4 mb-8">
        <h2 className="text-xl font-bold">添加文档到知识库</h2>
        
        <div>
          <label className="block text-sm font-medium mb-1">文章标题</label>
          <input
            type="text"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            className="w-full p-2 border rounded"
            placeholder="输入文章标题"
            required
          />
        </div>

        <div>
          <label className="block text-sm font-medium mb-1">文章链接</label>
          <input
            type="url"
            value={url}
            onChange={(e) => setUrl(e.target.value)}
            className="w-full p-2 border rounded"
            placeholder="https://juejin.cn/post/xxx"
            required
          />
        </div>

        <button
          type="submit"
          disabled={loading}
          className="px-6 py-2 bg-green-600 text-white rounded hover:bg-green-700 disabled:opacity-50"
        >
          {loading ? '添加中...' : '添加到知识库'}
        </button>

        {message && <p className="text-center font-medium">{message}</p>}
      </form>

      <div className="bg-white p-6 rounded-lg shadow">
        <h2 className="text-xl font-bold mb-4">知识库文档列表 ({docs.length})</h2>
        {docs.length === 0 ? (
          <p className="text-gray-500">暂无文档，请添加第一篇文档</p>
        ) : (
          <ul className="space-y-2">
            {docs.map((doc) => (
              <li key={doc.id} className="p-3 bg-gray-50 rounded flex justify-between items-center">
                <div>
                  <p className="font-medium">{doc.title}</p>
                  <a href={doc.url} target="_blank" className="text-sm text-blue-600 hover:underline">
                    {doc.url}
                  </a>
                </div>
                <span className="text-xs text-gray-400">
                  {new Date(doc.createdAt).toLocaleDateString()}
                </span>
              </li>
            ))}
          </ul>
        )}
      </div>
    </main>
  )
}
