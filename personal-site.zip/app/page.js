import Link from 'next/link'

export default function Home() {
  return (
    <main className="min-h-screen p-8 max-w-4xl mx-auto">
      <header className="flex justify-between items-center mb-12">
        <h1 className="text-2xl font-bold">陈碎篇</h1>
        <nav className="space-x-6">
          <Link href="/" className="text-blue-600 hover:underline">首页</Link>
          <Link href="/chat" className="text-blue-600 hover:underline">知识库问答</Link>
          <Link href="/admin" className="text-blue-600 hover:underline">管理</Link>
        </nav>
      </header>

      <section className="mb-12">
        <div className="flex items-center gap-6 mb-6">
          <div className="w-24 h-24 bg-gray-200 rounded-full flex items-center justify-center text-4xl">
            👨‍💻
          </div>
          <div>
            <h2 className="text-3xl font-bold mb-2">陈碎篇</h2>
            <p className="text-gray-600">全栈开发工程师 | AI 应用探索者</p>
            <div className="flex gap-2 mt-2">
              <span className="px-2 py-1 bg-blue-100 text-blue-800 text-sm rounded">React</span>
              <span className="px-2 py-1 bg-green-100 text-green-800 text-sm rounded">Node.js</span>
              <span className="px-2 py-1 bg-purple-100 text-purple-800 text-sm rounded">Next.js</span>
              <span className="px-2 py-1 bg-orange-100 text-orange-800 text-sm rounded">AI/RAG</span>
            </div>
          </div>
        </div>
      </section>

      <section className="mb-12">
        <h3 className="text-xl font-bold mb-4">关于我</h3>
        <p className="text-gray-700 leading-relaxed mb-4">
          热爱技术，专注于前端开发和 AI 应用。拥有丰富的全栈开发经验，
          熟悉 React、Vue、Node.js 等技术栈。目前正在探索 RAG 技术，
          希望将 AI 能力落地到实际应用中。
        </p>
        <a href="/resume.pdf" className="inline-block px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700">
          📄 下载简历
        </a>
      </section>

      <section className="mb-12">
        <h3 className="text-xl font-bold mb-4">开源项目</h3>
        <div className="grid md:grid-cols-2 gap-4">
          <div className="border rounded-lg p-4">
            <h4 className="font-bold">RAG 个人知识库</h4>
            <p className="text-gray-600 text-sm mb-2">基于 Ollama + Next.js 的 RAG 应用</p>
            <a href="https://github.com/chensuipian/rag-site" className="text-blue-600 text-sm">查看源码 →</a>
          </div>
          <div className="border rounded-lg p-4">
            <h4 className="font-bold">其他项目</h4>
            <p className="text-gray-600 text-sm mb-2">更多作品正在路上...</p>
            <a href="https://github.com/chensuipian" className="text-blue-600 text-sm">查看全部 →</a>
          </div>
        </div>
      </section>

      <section className="mb-12">
        <h3 className="text-xl font-bold mb-4">链接</h3>
        <div className="flex gap-4 flex-wrap">
          <a href="https://juejin.cn/user/chensuipian" className="px-4 py-2 bg-orange-500 text-white rounded hover:bg-orange-600">
            📝 稀土掘金
          </a>
          <a href="https://github.com/chensuipian" className="px-4 py-2 bg-gray-800 text-white rounded hover:bg-gray-900">
            🐙 GitHub
          </a>
          <Link href="/chat" className="px-4 py-2 bg-green-600 text-white rounded hover:bg-green-700">
            💬 AI 知识库
          </Link>
        </div>
      </section>

      <section className="mb-12">
        <h3 className="text-xl font-bold mb-4">联系方式</h3>
        <p className="text-gray-700">📧 chensuipian@email.com</p>
      </section>

      <footer className="text-center text-gray-500 text-sm">
        <p>© 2026 陈碎篇. 基于知识库的智能个人主页.</p>
      </footer>
    </main>
  )
}
