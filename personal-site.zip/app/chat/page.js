'use client'
import { useState } from 'react'
import Link from 'next/link'

export default function ChatPage() {
  const [question, setQuestion] = useState('')
  const [messages, setMessages] = useState([])
  const [loading, setLoading] = useState(false)

  const handleSubmit = async (e) => {
    e.preventDefault()
    if (!question.trim()) return

    const userMsg = { role: 'user', content: question }
    setMessages(prev => [...prev, userMsg])
    setQuestion('')
    setLoading(true)

    try {
      // 1. 搜索相关文档
      const searchRes = await fetch('/api/search', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ query: userMsg.content })
      })
      
      if (!searchRes.ok) {
        throw new Error('搜索服务不可用')
      }
      
      const { contexts, results, error: searchError } = await searchRes.json()

      if (searchError) {
        throw new Error(searchError)
      }

      // 2. 获取 AI 回答
      const chatRes = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          question: userMsg.content,
          context: contexts?.join('\n\n') || '知识库暂无相关文档。'
        })
      })
      
      const { answer, error: chatError } = await chatRes.json()

      setMessages(prev => [...prev, {
        role: 'assistant',
        content: chatError || answer,
        sources: results?.map(r => r.title) || []
      }])
    } catch (error) {
      setMessages(prev => [...prev, {
        role: 'assistant',
        content: `抱歉，${error.message || '服务暂时不可用，请稍后重试。'}`
      }])
    }

    setLoading(false)
  }

  return (
    <main className="min-h-screen p-8 max-w-4xl mx-auto">
      <header className="flex justify-between items-center mb-8">
        <h1 className="text-2xl font-bold">💬 知识库问答</h1>
        <nav className="space-x-6">
          <Link href="/" className="text-blue-600 hover:underline">首页</Link>
          <Link href="/chat" className="text-blue-600 hover:underline">问答</Link>
          <Link href="/admin" className="text-blue-600 hover:underline">管理</Link>
        </nav>
      </header>

      <div className="bg-gray-100 p-4 rounded-lg mb-6 text-sm text-gray-600">
        💡 本知识库基于稀土掘金学习文档构建，可以询问技术问题、作者分享的内容等。
      </div>

      <div className="space-y-4 mb-6 min-h-[400px]">
        {messages.length === 0 && (
          <div className="text-center text-gray-500 py-12">
            <p className="text-4xl mb-4">🤔</p>
            <p>问我任何关于稀土掘金文档的问题吧！</p>
          </div>
        )}
        {messages.map((msg, i) => (
          <div key={i} className={`p-4 rounded-lg ${msg.role === 'user' ? 'bg-blue-100 ml-12' : 'bg-gray-100 mr-12'}`}>
            <p className="font-bold mb-1">{msg.role === 'user' ? '👤 你' : '🤖 AI'}</p>
            <p className="whitespace-pre-wrap">{msg.content}</p>
            {msg.sources?.length > 0 && (
              <div className="mt-2 text-sm text-gray-500">
                📎 参考文档：
                {msg.sources.map((s, j) => <span key={j} className="ml-2">• {s}</span>)}
              </div>
            )}
          </div>
        ))}
        {loading && (
          <div className="p-4 bg-gray-100 rounded-lg">
            <span className="animate-pulse">🤔 AI 思考中...</span>
          </div>
        )}
      </div>

      <form onSubmit={handleSubmit} className="flex gap-2">
        <input
          type="text"
          value={question}
          onChange={(e) => setQuestion(e.target.value)}
          placeholder="输入你的问题..."
          className="flex-1 p-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
          disabled={loading}
        />
        <button
          type="submit"
          disabled={loading}
          className="px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50"
        >
          发送
        </button>
      </form>
    </main>
  )
}
